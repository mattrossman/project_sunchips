package com.example.andrew.tutorial;

/**
 * Created by Andrew on 11/4/2017.
 */

public class Trip {
    private Vehicle vehicle; //the active vehicle used for this trip
    private double distance; //the distance traveled in this trip
    private int hours;
    private int minutes;
    private double seconds;
}
